package br.com.palindromos;

public class VereficarPalindromo {
	
	/**
	 * @author edimo
	 */
	
	Vetor palavra = new Vetor(5);
	Vetor palavra_ao_Contrario = new Vetor(5);
	
	/**
	 * 
	 * Esse metodo recebe uma String como parametro, dividea em varias substrings, pegando letra por letra da
	 * string e colocando cada letra em um vetor, depois faz a mesma coisa s� que
	 * armazenando em outro vetor e dessa vez pegando as letras do final pro inicio,
	 * e por fim verefica se um vetor � igual ao outro, ou seja se uma palavra � palindromo ou n�o.
	 * 
	 * @param palavra1 --> recebe como parametro uma String que ser� avalida palindromo ou n�o
	 */
	public void testarPalindromo (String palavra1) {
		
		/*
		 * Aqui estou apenas armazenando letra por letra da string pasada como parametro em um vetor
		 */
		
		for(int i = 0; i <= palavra1.length() - 1; i++) {
			String letra = palavra1.substring(i, i+1);
			//System.out.println(letra);
			try {
				palavra.adiciona(letra);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		/*
		 * Aqui estou testando o vetor preenchido com todas letras da string informada
		 */
		System.out.println(palavra);
		System.out.println(palavra.tamanho);
		
		/*
		 * aqui estou pasando letra por letra da palavra para um outro vetor, s� que agora
		 * de tr�s para frente
		 */
		String aux;
		for(int j = 0, i = palavra.tamanho - 1; i >= 0; i--, j++) {
			aux = palavra.busca(i);
			try {
				palavra_ao_Contrario.adiciona(aux);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		/*
		 * apenas testando o segundo vetor com todas letras de tr�s pra frente
		 */
		System.out.println(palavra_ao_Contrario);
		System.out.println(palavra_ao_Contrario.tamanho);
		
		int vereficacao = 0;
		/*
		 * por fim vereficando se a palavra e palindromo ou n�o comprando os vetores criados.
		 */
		for(int i = 0; i <= palavra1.length() - 1; i++) {
			
			if (!(palavra.busca(i).equals(palavra_ao_Contrario.busca(i)))) {
				System.out.println("sua palavra n�o � palindromo");
				vereficacao++;
				return;
			}
			
		}
		
		System.out.println("Sua palavra � palindromo!!!");
		
	}

}
