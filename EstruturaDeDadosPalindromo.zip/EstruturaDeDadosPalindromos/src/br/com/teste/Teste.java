package br.com.teste;

import br.com.palindromos.VereficarPalindromo;

public class Teste {
	
	/**
	 * @author edimo
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VereficarPalindromo palindromo = new VereficarPalindromo();
		palindromo.testarPalindromo("abasedotetodesaba");
		
		// Testando: a base do teto desaba!
	}

}
